Copy these files to:

-Raspbian prior to Bookworm: /boot/
-Since Bookworm: /boot/firmware/